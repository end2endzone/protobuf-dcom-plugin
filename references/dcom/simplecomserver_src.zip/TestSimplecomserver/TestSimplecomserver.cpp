// TestSimplecomserver.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "TestSimplecomserver.h"
#include "TestSimplecomserverDlg.h"

#include <atlbase.h>
#include "..\simplecomserver\simplecomserver_i.h" // interface declaration
#include "..\simplecomserver\simplecomserver_i.c" // IID, CLSID

#include <comutil.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestSimplecomserverApp

BEGIN_MESSAGE_MAP(CTestSimplecomserverApp, CWinApp)
	//{{AFX_MSG_MAP(CTestSimplecomserverApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestSimplecomserverApp construction

CTestSimplecomserverApp::CTestSimplecomserverApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CTestSimplecomserverApp object

CTestSimplecomserverApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CTestSimplecomserverApp initialization

typedef void (*myFunc)();

void AfxBSTR2CString(BSTR bstrstring, CString &szOutput)
{
	szOutput.Empty();

	_bstr_t bstrTag;
	bstrTag = bstrstring;

	UINT uLen = bstrTag.length();
	TCHAR *szTemp= new TCHAR[uLen+1];
	memset (szTemp, 0, uLen+1);

	LPOLESTR wszTag = bstrTag;

	int iBytes = ::WideCharToMultiByte(CP_ACP, 0,
			wszTag, uLen,
			szTemp, uLen, NULL, NULL);

	szOutput = szTemp;

	delete [] szTemp;
}

void __stdcall _com_issue_error(HRESULT)
{}


BOOL CTestSimplecomserverApp::InitInstance()
{
	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	::CoInitialize(NULL);

	ICOMServer *p = NULL;

	// create an instance
	HRESULT hr = CoCreateInstance(	CLSID_CoCOMServer, NULL, CLSCTX_ALL ,
									IID_ICOMServer, 
									(void **)&p);
	if (SUCCEEDED(hr))
	{
		// call the (only) method exposed by the main interface
		//
		BSTR message;
		
		hr = p->Name(&message);

		// if everything went well, message holds the returned name
		//
		// ...
		CString szMessage;
		AfxBSTR2CString(message, szMessage);
		AfxMessageBox(szMessage);

		// don't forget to release the stuff
		::SysFreeString(message);
	}

	p->Release();

	::CoUninitialize();



/*
	CTestSimplecomserverDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}
*/

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}


