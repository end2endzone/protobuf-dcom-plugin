// automexeserver.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include <objbase.h> // 
#include "automexeserver_i.h"
#include "automexeserverImpl.h"

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{

	// register/unregister server on demand
	//
	char szUpperCommandLine[MAX_PATH];
	strcpy (szUpperCommandLine, lpCmdLine); // copy command line and work with it.
	strupr (szUpperCommandLine);
	if (strstr (szUpperCommandLine, "UNREGSERVER"))
	{
		DllUnregisterServer();
		return 0;
	}
	else if (strstr (szUpperCommandLine, "REGSERVER"))
	{
		DllRegisterServer();
		return 0;
	}


	// initialize the COM library
	::CoInitialize(NULL);

	// register ourself as a class object against the internal COM table
	// (this has nothing to do with the registry)
	DWORD nToken = CoEXEInitialize();


	// -- the message poooommmp ----------------
	//
	// (loop ends if WM_QUIT message is received)
	//
	MSG msg;
	while (GetMessage(&msg, 0, 0, 0) > 0) 
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
		

	// unregister from the known table of class objects
	CoEXEUninitialize(nToken);

	// 
	::CoUninitialize();


	

	return 0;
}



